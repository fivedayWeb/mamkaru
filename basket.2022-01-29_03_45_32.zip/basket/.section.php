<?
$sSectionName = "Корзина";
$arDirProperties = Array(

);
?>